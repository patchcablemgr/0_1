* - Do not edit or delete data in this column unless deleting the entire row.
** - Do not edit or delete data in this column unless deleting the entire row or adding a new row.